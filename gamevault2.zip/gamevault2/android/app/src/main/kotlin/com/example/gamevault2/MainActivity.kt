package com.example.gamevault2

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
